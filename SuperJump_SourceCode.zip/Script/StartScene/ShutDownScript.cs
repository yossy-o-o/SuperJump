using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShutDownScript : MonoBehaviour
{
    public void OnclickEndButton()
    {
       Application.Quit();
    }
}
